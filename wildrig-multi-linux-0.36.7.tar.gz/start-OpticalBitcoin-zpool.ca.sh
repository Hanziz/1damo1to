#!/bin/bash

while true
do
./wildrig-multi --algo heavyhash --url stratum+tcp://heavyhash.mine.zpool.ca:5138 --user bc1qyfldctp2f09a2pydfepzfz2f924uxnmt8huxx9 --pass c=OBTC,zap=OBTC
sleep 5
done
