#!/bin/bash

while true
do
./wildrig-multi --algo x25x --url stratum+tcp://stratum.pool4u.net:8202 --user SZtksJMZNivUKBp46necBBXZa7ZfxxJ9zS --pass c=SIN
sleep 5
done
