#!/bin/bash

while true
do
./wildrig-multi --algo memehashv2 --url stratum+tcp://stratum-eu.rplant.xyz:7097 --user PC1QXZFA9GVYMNPQGYHKSX4PGHM5LLU3V7CRCANZE0 --pass x
sleep 5
done
