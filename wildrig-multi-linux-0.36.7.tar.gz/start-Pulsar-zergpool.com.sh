#!/bin/bash

while true
do
./wildrig-multi --algo curvehash --url stratum+tcp://curvehash.mine.zergpool.com:3343 --user PELGJ7KYEnv4k3mdcRvdK6iuSADDHX7YwN --pass c=PLSR,mc=PLSR
sleep 5
done
