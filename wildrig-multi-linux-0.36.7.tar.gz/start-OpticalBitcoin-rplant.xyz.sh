#!/bin/bash

while true
do
./wildrig-multi --algo heavyhash --url stratum+tcp://stratum-eu.rplant.xyz:7064 --user PoolDonateWallet --pass x
sleep 5
done
