#!/bin/bash

while true
do
./wildrig-multi --algo evrprogpow --url stratum+tcp://stratum-eu.rplant.xyz:7073 --user PoolDonateWallet --pass x
sleep 5
done
