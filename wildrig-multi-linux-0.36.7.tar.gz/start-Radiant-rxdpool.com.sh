#!/bin/bash

while true
do
./wildrig-multi --algo sha512256d --url stratum+tcp://rxdpool.com:3025 --user RS1bE7X584q2AVMAp35hDhWrQgrL1RyPbS --pass x
sleep 5
done
