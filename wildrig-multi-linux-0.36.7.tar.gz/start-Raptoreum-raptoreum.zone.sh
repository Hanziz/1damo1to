#!/bin/bash

while true
do
./wildrig-multi --algo ghostrider --url stratum+tcp://europe-1.raptoreum.zone:3333 --user RCQMzucqevALkHCPKH7xrp5ieLUBwmhLYq --pass x
sleep 5
done
