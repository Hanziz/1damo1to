#!/bin/bash

while true
do
./wildrig-multi --algo evrprogpow --url stratum+tcp://stratum.evrpool.com:1111 --user Ef2EXrmvNhFPS7GEx4toSxEMMSoPtUg2iA --pass x
sleep 5
done
