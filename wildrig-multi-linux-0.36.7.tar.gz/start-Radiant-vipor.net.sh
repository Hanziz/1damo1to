#!/bin/bash

while true
do
./wildrig-multi --algo sha512256d --url stratum+tcp://rxd.vipor.net:5066 --user RS1bE7X584q2AVMAp35hDhWrQgrL1RyPbS --pass x
sleep 5
done
