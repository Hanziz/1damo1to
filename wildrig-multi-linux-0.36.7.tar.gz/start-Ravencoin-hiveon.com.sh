#!/bin/bash

while true
do
./wildrig-multi --algo kawpow --protocol stratum1 --url stratum+tcp://rvn.hiveon.com:8888 --worker test --user RETVhu5dA6EUwpzvkbGxRAVZAmVFimzMQp --pass x
sleep 5
done
