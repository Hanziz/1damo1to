#!/bin/bash

while true
do
./wildrig-multi --algo kawpow --url stratum+tcp://stratum-ravencoin.flypool.org:3333 --worker test --user RETVhu5dA6EUwpzvkbGxRAVZAmVFimzMQp --pass x
sleep 5
done
