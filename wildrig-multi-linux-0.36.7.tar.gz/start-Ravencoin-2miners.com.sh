#!/bin/bash

while true
do
./wildrig-multi --algo kawpow --url stratum+tcp://rvn.2miners.com:6060 --worker test --user RETVhu5dA6EUwpzvkbGxRAVZAmVFimzMQp --pass x
sleep 5
done
