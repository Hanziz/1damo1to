#!/bin/bash

while true
do
./wildrig-multi --algo memehash --url stratum+tcp://stratum-eu.rplant.xyz:7019 --user PAWBjrHrrYXtrDhfA6MELN3bWuuYNJ9NRS --pass x
sleep 5
done
