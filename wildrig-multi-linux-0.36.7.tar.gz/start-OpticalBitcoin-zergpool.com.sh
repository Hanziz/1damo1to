#!/bin/bash

while true
do
./wildrig-multi --algo heavyhash --url stratum+tcp://heavyhash.mine.zergpool.com:5137 --user bc1qyfldctp2f09a2pydfepzfz2f924uxnmt8huxx9 --pass c=OBTC,mc=OBTC
sleep 5
done
